package com.Watumull.OnShop;

//Concrete class GSPrimeAcc extending PrimeAcc
class GSPrimeAcc extends PrimeAcc {
 private static final float Charges = 0.0f;

 public GSPrimeAcc(int accNo, String accNm, float charges, boolean isPrime) {
     super(accNo, accNm, charges, isPrime);
 }

 @Override
 public void bookProduct(float price) {
     System.out.println("GS Prime product booked with price: " + price + ". No delivery charges applied.");
 }

 @Override
 public String toString() {
     return super.toString() + " GSPrimeAcc{}";
 }

@Override
public void items(float quantity) {
	// TODO Auto-generated method stub
	
}
}
