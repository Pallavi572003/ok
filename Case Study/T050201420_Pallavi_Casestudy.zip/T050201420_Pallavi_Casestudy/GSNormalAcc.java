package com.Watumull.OnShop;

//Concrete class GSNormalAcc extending NormalAcc
class GSNormalAcc extends NormalAcc {
 public GSNormalAcc(int accNo, String accNm, float charges, float deliveryCharges) {
     super(accNo, accNm, charges, deliveryCharges);
 }

 @Override
 public void bookProduct(float price) {
     System.out.println("GS Normal product booked with price: " + price + ". Delivery charges applied: " + getDeliveryCharges());
 }

 @Override
 public String toString() {
     return super.toString() + " GSNormalAcc{}";
 }

@Override
public void items(float quantity) {
	// TODO Auto-generated method stub
	
}
}
