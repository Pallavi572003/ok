package com.Watumull.OnShop;

//Entry point for the application
public class Main {
 public static void main(String[] args) {
     // Assign instance of GSShopFactory to ShopFactory reference
     ShopFactory shopFactory = new GSShopFactory();

     // Instantiate GSPrimeAcc and refer it through reference PrimeAcc
     PrimeAcc primeAcc = shopFactory.getNewPrimeAcc(101, "Shardul", 999.99f, true);
     primeAcc.bookProduct(499.99f);
     System.out.println(primeAcc.toString());

     // Instantiate GSNormalAcc and refer it through reference NormalAcc
     NormalAcc normalAcc = shopFactory.getNewNormalAcc(102, "Shardul", 499.99f, 50.0f);
     normalAcc.bookProduct(199.99f);
     System.out.println(normalAcc.toString());
 }
}
