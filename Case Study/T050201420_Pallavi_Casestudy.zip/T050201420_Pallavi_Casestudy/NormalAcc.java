package com.Watumull.OnShop;

//Abstract class NormalAcc extending ShopAcc
abstract class NormalAcc extends ShopAcc {
 private final float deliveryCharges;

 public NormalAcc(int accNo, String accNm, float charges, float deliveryCharges) {
     super(accNo, accNm, charges);
     this.deliveryCharges = deliveryCharges;
 }

 public float getDeliveryCharges() {
     return deliveryCharges;
 }

 @Override
 public void bookProduct(float price) {
     System.out.println("Normal product booked with price: " + price + ". Delivery charges applied: " + deliveryCharges);
 }

 @Override
 public String toString() {
     return super.toString() + " NormalAcc{" +
             "deliveryCharges=" + deliveryCharges +
             '}';
 }
}
